# -*- coding: UTF-8 -*-
""" check correct wrong encoding declaration
"""

__revision__ = '����'

