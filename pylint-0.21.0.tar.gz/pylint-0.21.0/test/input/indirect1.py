class TotoInterface:
    def machin(self):
        raise NotImplementedError
    
